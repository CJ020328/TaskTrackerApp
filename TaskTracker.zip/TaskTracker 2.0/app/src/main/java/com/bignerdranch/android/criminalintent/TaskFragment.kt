package com.bignerdranch.android.criminalintent

import android.app.DatePickerDialog
import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.DatePicker
import android.widget.EditText
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProviders
import java.text.SimpleDateFormat
import java.util.*

private const val ARG_TASK_ID = "task_id"
private const val DIALOG_DATE = "DialogDate"
private const val REQUEST_DATE = 0

class TaskFragment : Fragment(), DatePickerFragment.Callbacks {
    private lateinit var task: Task
    private lateinit var titleField: EditText
    private lateinit var dueDateButton: Button
    private lateinit var completedCheckBox: CheckBox
    private lateinit var deleteButton: Button

    private val taskDetailViewModel: TaskDetailViewModel by lazy {
        ViewModelProviders.of(this).get(TaskDetailViewModel::class.java)
    }

    companion object {
        fun newInstance(taskId: UUID): TaskFragment {
            val args = Bundle().apply {
                putSerializable(ARG_TASK_ID, taskId)
            }
            return TaskFragment().apply {
                arguments = args
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val taskId: UUID = arguments?.getSerializable(ARG_TASK_ID) as UUID
        taskDetailViewModel.loadTask(taskId)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_task, container, false)
        titleField = view.findViewById(R.id.task_title)
        dueDateButton = view.findViewById(R.id.task_due_date)
        completedCheckBox = view.findViewById(R.id.task_completed)
        deleteButton = view.findViewById(R.id.task_delete)
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        taskDetailViewModel.taskLiveData.observe(
            viewLifecycleOwner
        ) { task ->
            task?.let {
                this.task = task
                updateUI()
            }
        }

        dueDateButton.setOnClickListener {
            DatePickerFragment.newInstance(task.dueDate ?: Date()).apply {
                setTargetFragment(this@TaskFragment, REQUEST_DATE)
                show(this@TaskFragment.requireFragmentManager(), DIALOG_DATE)
            }
        }

        val submitButton: Button = view.findViewById(R.id.submit_button)
        submitButton.setOnClickListener {
            saveTask()
            activity?.supportFragmentManager?.popBackStack()
        }

        deleteButton.setOnClickListener {
            taskDetailViewModel.deleteTask(task)
            activity?.supportFragmentManager?.popBackStack()
        }
    }

    private fun updateUI() {
        titleField.setText(task.title)
        dueDateButton.text = task.dueDate?.let {
            val formatter = SimpleDateFormat("EEE, MM, dd", Locale.getDefault())
            formatter.format(it)
        } ?: "Select Due Date"
        completedCheckBox.isChecked = task.isCompleted
    }

    override fun onDateSelected(date: Date) {
        task.dueDate = date
        updateUI()
    }

    private fun saveTask() {
        task.title = titleField.text.toString()
        taskDetailViewModel.saveTask(task)
    }
}
