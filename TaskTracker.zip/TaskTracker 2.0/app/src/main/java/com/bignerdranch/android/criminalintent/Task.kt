package com.bignerdranch.android.criminalintent

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.*

@Entity
data class Task(
    @PrimaryKey var id: UUID = UUID.randomUUID(),
    var title: String = "",
    var dueDate: Date? = null,
    var isCompleted: Boolean = false,
    var reminderDate: Date? = null
)
