package com.bignerdranch.android.criminalintent

import android.app.Application

class TaskTrackerApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        TaskRepository.initialize(this)
    }
}
